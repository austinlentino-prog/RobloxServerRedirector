# Roblox Server Redirector
Theos project + Debian package + Cydia/APT repository scaffold.

Package ID: com.austin.robloxserverredirector
Version: 1.0.0-1
Architecture: iphoneos-arm (armv7)

Put the compiled armv7 dylib at:
Package/Library/MobileSubstrate/DynamicLibraries/RobloxServerRedirector.dylib
